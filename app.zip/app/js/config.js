"use strict";

 angular.module('constantes', [])

.constant('ENV', {name:'development',APIEndPoint:'http://192.168.0.30/'})

;