'use strict';

angular.module('catchaiApp.EventosListaController', ['ngRoute'])

.controller('EventosListaController', ['$scope', '$routeParams','$location','EventoDAO',

  function($scope, $routeParams, $location, EventoDAO){

	$scope.init = function(){
		console.log("EventosListaController.js: init();");
		$scope.eventosCargar(1);
	};

	$scope.eventosCargar = function(pagina){
		$scope.model.pagina = pagina;
	  	EventoDAO.obtenerConPagina($scope.model.pagina).then(function(data){
	  		if(data.result){
		  		$scope.model.eventos = data.eventos;		  			
	  		} else {
	  			console.error(data.errores);
	  		}
	  	}, function(data) {
	  		
	  	});
	}

	$scope.irGifs = function(evento){
		console.log(evento);
		$scope.model.evento = evento;
		$location.path('/gifs/'+evento.idevento);
	}

	$scope.irEditar = function(evento){
		$scope.model.evento = evento;
		$location.path('/evento/editar/'+evento.idevento);
	}

	$scope.eventoEliminar = function(evento){
		console.log(evento);
	}

  }

]);